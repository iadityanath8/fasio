"""

    Not implemented yet thinking of implementing file io as a combination of the 
    ThreadPool mechainism and the O_DIrect Dma mechainism in linux kernel 

    we also thought of using new asyncronous IO mechainism known as linux kernel 


    to make this cross platform we will be using a linux IO asyncronous mechainsm for linux (obiously)
    and right now thread pool mechainism for windows and other OS 

    !!!!!

 !!!!!!!!!  NOT IMPLEMENTED  !!!!!!!!!
"""